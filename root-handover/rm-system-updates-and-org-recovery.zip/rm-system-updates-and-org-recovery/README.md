# RM System handover package

Built 17 October 2026 from the Claude Code chat "RM System updates and org recovery".
Companion to rm-system-updates-and-org-recovery.md (included here as HANDOVER.md).

## What is inside

- HANDOVER.md: the full handover record for this chat.
- app/index.html: the RM System app exactly as this chat left it (branch
  claude/cartrack-rm-system-access-humtqk, commit 7d80bb3, 23 July 2026),
  SANITISED. Not runnable as is: the database URL and key are placeholders
  and all seed data is removed. Keep it as a reference for the patterns
  (single-file PWA, Supabase storage routing, PIN gate, My Day cockpit,
  celebration screen), not as a product.
- demo/celebrate.html: standalone recreation of the deal-signed confetti
  screen, with placeholder client and premium.
- demo/shot.js: Playwright script that screenshots the demo (rewritten for
  this package; the original was equivalent but is lost).

## What was removed or replaced

- Supabase project URL and anon key: placeholders.
- Two operator master keys, the operator code and three hard-wired staff
  passcodes: dummy values (PASS_A_REDACTED, 000000, 111111, etc.).
- All seeded deal, portfolio, house-account and deduction data (about 40 KB
  of real client records): emptied.
- Every staff first name and surname: replaced with consistent placeholder
  names (Ash, Blake, Casey, Devon, Ellis, Frankie, Gray, Morgan, Taylor,
  Jordan, Owner), so the code still reads coherently.
- The live production files were NOT touched; this is a copy.

## Not included, and why

- The team communications (deal-signed message, outage explanations in
  English and Afrikaans): they existed only in chat and their verbatim text
  was lost to context compaction before this package was made.
- The client proposal PDF: client data end to end; nothing to strip.
- sw.js, manifest and icons: employer branding, and unchanged by this chat.
