// Screenshot celebrate.html headlessly. Rewritten for this package; the
// original script from the chat session was equivalent but is lost.
// In the Claude Code cloud sandbox run with:
//   NODE_PATH=/opt/node22/lib/node_modules node shot.js
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const page = await browser.newPage({ viewport: { width: 600, height: 500 } });
  await page.goto('file://' + __dirname + '/celebrate.html');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'celebrate.png' });
  await browser.close();
})();
